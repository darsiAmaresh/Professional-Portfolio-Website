import React, { useState, useEffect } from 'react';
import { Menu, X, Github, Linkedin, Mail, ExternalLink, Code } from 'lucide-react';

// Project data
const projects = [
  {
    id: 1,
    title: "Portfolio Website",
    description: "A personal portfolio website showcasing my skills and projects, built with responsive design principles.",
    tags: ["HTML", "CSS", "JavaScript"],
    image: "https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    demoLink: "http://darsiamaresh.ccbp.tech/",
    codeLink: "https://github.com/darsiAmaresh"
  },
  {
    id: 2,
    title: "Flat Landing Page",
    description: "A modern landing page for real estate properties with interactive features and smooth animations.",
    tags: ["HTML", "CSS", "JavaScript"],
    image: "https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    demoLink: "http://amareshflatpage.ccbp.tech/",
    codeLink: "https://github.com/darsiAmaresh"
  },
  {
    id: 3,
    title: "Article Page",
    description: "A clean and readable article page with optimal typography and user experience.",
    tags: ["HTML", "CSS"],
    image: "https://images.pexels.com/photos/261662/pexels-photo-261662.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    demoLink: "http://darticalpage.ccbp.tech/",
    codeLink: "https://github.com/darsiAmaresh"
  },
  {
    id: 4,
    title: "Python Calculator",
    description: "A command-line calculator application built with Python, supporting basic arithmetic operations.",
    tags: ["Python"],
    image: "https://images.pexels.com/photos/4386326/pexels-photo-4386326.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    demoLink: "https://github.com/darsiAmaresh/sample-calculator.py",
    codeLink: "https://github.com/darsiAmaresh/sample-calculator.py"
  }
];

// Skills data
const skills = [
  { name: "HTML5", level: 90 },
  { name: "CSS3", level: 85 },
  { name: "JavaScript", level: 80 },
  { name: "Python", level: 75 },
  { name: "MySQL", level: 70 },
  { name: "Git/GitHub", level: 85 },
  { name: "Flexbox", level: 90 },
  { name: "Responsive Design", level: 85 }
];

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState("All");
  const [filteredProjects, setFilteredProjects] = useState(projects);
  const [isScrolled, setIsScrolled] = useState(false);

  // Handle scroll for navbar styling
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Filter projects based on selected tag
  useEffect(() => {
    if (activeFilter === "All") {
      setFilteredProjects(projects);
    } else {
      setFilteredProjects(
        projects.filter(project => 
          project.tags.some(tag => tag.toLowerCase() === activeFilter.toLowerCase())
        )
      );
    }
  }, [activeFilter]);

  // Get unique tags for filter
  const allTags = ["All", ...new Set(projects.flatMap(project => project.tags))];

  // Smooth scroll to section
  const scrollToSection = (sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  return (
    <div className="font-sans text-gray-800">
      {/* Navigation */}
      <header className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'}`}>
        <div className="container mx-auto px-4 md:px-6">
          <nav className="flex justify-between items-center">
            <a href="#" className="text-2xl font-bold text-indigo-600">
              Portfolio
            </a>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex space-x-8">
              {['hero', 'about', 'skills', 'projects', 'contact'].map((section) => (
                <button 
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className="text-gray-700 hover:text-indigo-600 capitalize"
                >
                  {section}
                </button>
              ))}
            </div>
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-gray-700"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </nav>
        </div>
        
        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white shadow-lg absolute w-full">
            <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
              {['hero', 'about', 'skills', 'projects', 'contact'].map((section) => (
                <button 
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className="text-gray-700 hover:text-indigo-600 py-2 capitalize"
                >
                  {section}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section id="hero" className="min-h-screen flex items-center bg-gradient-to-br from-indigo-50 to-purple-50 pt-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 text-gray-900">
                Hi, I'm <span className="text-indigo-600">Amaresh</span>
              </h1>
              <h2 className="text-2xl md:text-3xl font-medium mb-6 text-gray-700">
                B.Tech Student & Developer
              </h2>
              <p className="text-lg text-gray-600 mb-8 max-w-lg">
                Passionate about Computer Science Engineering and embracing innovation. I build exceptional digital experiences and am always eager to learn and contribute to meaningful projects.
              </p>
              <div className="flex space-x-4">
                <button 
                  onClick={() => scrollToSection('projects')}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-300"
                >
                  View My Work
                </button>
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="border-2 border-indigo-600 text-indigo-600 hover:bg-indigo-50 px-6 py-3 rounded-lg font-medium transition-colors duration-300"
                >
                  Contact Me
                </button>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="w-64 h-64 md:w-80 md:h-80 rounded-full bg-indigo-200 flex items-center justify-center">
                <span className="text-indigo-600 text-6xl font-bold">A</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">About Me</h2>
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <div className="bg-gray-100 p-1 rounded-lg">
                <div className="aspect-w-4 aspect-h-3 rounded-lg overflow-hidden">
                  <img 
                    src="https://images.pexels.com/photos/3771089/pexels-photo-3771089.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                    alt="Developer working" 
                    className="object-cover w-full h-full"
                  />
                </div>
              </div>
            </div>
            <div className="md:w-1/2 md:pl-12">
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Who I Am</h3>
              <p className="text-gray-700 mb-6">
                I'm a passionate B.Tech student specializing in Computer Science Engineering. My journey in technology began with a curiosity about how computers work and how they can be used to solve real-world problems.
              </p>
              <p className="text-gray-700 mb-6">
                Currently pursuing my degree, I focus on building strong foundations in programming and web development. I enjoy creating responsive websites and applications that provide great user experiences.
              </p>
              <p className="text-gray-700 mb-6">
                When I'm not coding, I'm exploring new technologies, working on personal projects, or contributing to the developer community.
              </p>
              <div className="flex space-x-4">
                <a href="https://github.com/darsiAmaresh" target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:text-indigo-800">
                  <Github size={24} />
                </a>
                <a href="http://www.linkedin.com/in/darsi-amaresh" target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:text-indigo-800">
                  <Linkedin size={24} />
                </a>
                <a href="mailto:amareshyadhav369@gmail.com" className="text-indigo-600 hover:text-indigo-800">
                  <Mail size={24} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">My Skills</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {skills.map((skill, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex justify-between mb-2">
                  <span className="font-medium">{skill.name}</span>
                  <span className="text-indigo-600">{skill.level}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-indigo-600 h-2.5 rounded-full" 
                    style={{ width: `${skill.level}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">My Projects</h2>
          <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">
            Here are some of my recent projects. Each one represents a step in my learning journey and demonstrates my skills in different technologies.
          </p>
          
          {/* Project Filters */}
          <div className="flex flex-wrap justify-center gap-2 mb-12">
            {allTags.map((tag, index) => (
              <button
                key={index}
                onClick={() => setActiveFilter(tag)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-300 ${
                  activeFilter === tag 
                    ? 'bg-indigo-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
          
          {/* Projects Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
            {filteredProjects.map((project) => (
              <div key={project.id} className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:-translate-y-2">
                <div className="relative h-60 overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                  <p className="text-gray-600 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag, index) => (
                      <span key={index} className="bg-indigo-100 text-indigo-800 text-xs px-3 py-1 rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex space-x-3">
                    <a 
                      href={project.demoLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center text-indigo-600 hover:text-indigo-800"
                    >
                      <ExternalLink size={16} className="mr-1" /> Live Demo
                    </a>
                    <a 
                      href={project.codeLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center text-indigo-600 hover:text-indigo-800"
                    >
                      <Code size={16} className="mr-1" /> View Code
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-indigo-50">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Get In Touch</h2>
          <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/3 bg-indigo-600 text-white p-8">
                <h3 className="text-2xl font-bold mb-6">Contact Info</h3>
                <div className="space-y-6">
                  <div className="flex items-start">
                    <Mail className="mr-4 mt-1" size={20} />
                    <div>
                      <h4 className="font-medium">Email</h4>
                      <p className="text-indigo-200">amareshyadhav369@gmail.com</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Linkedin className="mr-4 mt-1" size={20} />
                    <div>
                      <h4 className="font-medium">LinkedIn</h4>
                      <p className="text-indigo-200">darsi-amaresh</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Github className="mr-4 mt-1" size={20} />
                    <div>
                      <h4 className="font-medium">GitHub</h4>
                      <p className="text-indigo-200">darsiAmaresh</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="md:w-2/3 p-8">
                <form className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="your.email@example.com"
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                      Message
                    </label>
                    <textarea
                      id="message"
                      rows={4}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="Your message"
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-md transition-colors duration-300"
                  >
                    Send Message
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <h2 className="text-2xl font-bold">Portfolio</h2>
              <p className="text-gray-400 mt-2">Building the future through code.</p>
            </div>
            <div className="flex space-x-6">
              <a href="https://github.com/darsiAmaresh" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors duration-300">
                <Github size={24} />
              </a>
              <a href="http://www.linkedin.com/in/darsi-amaresh" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors duration-300">
                <Linkedin size={24} />
              </a>
              <a href="mailto:amareshyadhav369@gmail.com" className="text-gray-400 hover:text-white transition-colors duration-300">
                <Mail size={24} />
              </a>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Darsi Amaresh. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;